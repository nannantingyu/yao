function setorder(val,id,table){
    if(val){
        $.post('/admin.php/base/setorder',{val:val,id:id,table:table},function(d){
            window.location.href=window.location.href;
        });
    }else{
        alert('请输入数字排序号');
    }
}

function setlft(val,id,table){
    
    if(val){
        $.post('/admin.php/base/setlft',{val:val,id:id,table:table},function(d){
            window.location.href=window.location.href;
        });
    }else{
        alert('请输入数字排序号');
    }
}

