(function(){
    var selectIds = [];
    var PUB = 1,    //文章发布状态
        CPUB = -2,  //文章取消发布状态
        TG = 1,     //文章推广状态
        CTG = 0;    //文章取消推广
    var OP_MOVE = 1,
        OP_COPY = 2,
        OP_PUB = 3,
        OP_CANCEL_PUB = 4,
        OP_TG = 5,
        OP_CTG = 6,
        opNow = OP_MOVE;
    var ini_typeweb = "",
        ini_status = "",
        ini_catid = "",
        ini_self = 0,
        ini_keyword = "";

    $(function () {

        ini_typeweb = $("#hidden-typeweb").val() || "";
        ini_status = $("#hiddenstatus").val() || 1;
        ini_catid = $("#hidden-catid").val() || -1;
        ini_self = $("#contentSelf").val() || 0;
        ini_keyword = $("#contentKeyword").val() || "";

        $("#content-search").val(ini_keyword);

        //初始化分类
        catManager.init(ini_catid).done(function(){
            var param = {
            };

            catManager.buildCatgory();
            var panel = catManager.getCatPanel();
            $("#hj").html(panel.hj);
            $("#sh").html(panel.sh);
            $("#jf").html(panel.jf);
            var slevel = catManager.getLevelTree(ini_catid);
            if(slevel[0]){
                $("#moveWeb").val(slevel[0].typeweb).change();

                $('#a'+slevel[0].typeweb).tab('show');
            }

            /***************面包屑导航****************/
            var crumb = catManager.getCrumb(param, slevel);
            $(".breadcrumb").append(crumb);
            var lastLi = $(".breadcrumb li:last");
            var tx = lastLi.children("a").text();
            lastLi.html(tx);
        });

        $("#contentState").change(function(){
            var param = {
                typeweb: ini_typeweb,
                state: $(this).val(),
                keyword: ini_keyword,
                self: ini_self,
                catid: ini_catid
            };
            var href = catManager.createUrl(param)

            window.location.href = href;

        });

        $("#selfContent").change(function(){
            var self = 0;
            if($(this).prop("checked")){
                self = 1;
            }
            var param = {
                typeweb: ini_typeweb,
                state: ini_status,
                keyword: ini_keyword,
                self: self,
                catid: ini_catid
            };

            var href = catManager.createUrl(param);
            window.location.href = href;
        });

        //搜索
        $("#btn-search").click(function(){
            var srTxt = $("#content-search").val(),
                srType = $('#stype').val();

            var param = {
                typeweb: ini_typeweb,
                state: ini_status,
                self: ini_self,
                catid: ini_catid
            };

            var href = catManager.createUrl(param);
            if(!srTxt){
                window.location.href = href;
                return;
            }

            href += "srtype/" + srType + "/keyword/" + srTxt;
            window.location.href = href;
        });

        /***********************************编辑文章Modal*********************************/
            //网站改变事件
        $("#moveWeb").change(function(){
            var typeweb = $(this).val();
            var yjOptions = "";
            for(var ob in catManager.yjcatMenu){
                if(catManager.yjcatMenu[ob].typeweb == typeweb) {
                    yjOptions += "<option value=" + catManager.yjcatMenu[ob].id + ">" + catManager.yjcatMenu[ob].title + "</option>";
                }
            }

            $("#yj-cat-div").show();
            $("#yj-cat").empty().html(yjOptions).change();
        });

        //一级栏目改变事件
        $("#yj-cat").change(function(){
            var yjid = $(this).val();

            changeSelectOptions("ej-cat", "ej-cat-div", catManager.ejcatMenu["a" + yjid], ["ej-cat-div", "sj-cat-div"]);
        });

        //二级栏目改变事件
        $("#ej-cat").change(function(){
            var ejid = $(this).val();

            changeSelectOptions("sj-cat", "sj-cat-div", catManager.sjcatMenu["a" + ejid], ["sj-cat-div"]);
        });

        //点击执行的事件处理
        $("#selectSubmit").click(function(){

            var catid = getSelectedCatid();

            if(catid == -1){
                bootbox.alert("操作失败，请选择分类！");
                return;
            }
            var url = opNow == OP_MOVE?"/admin.php/content/moveContent":"/admin.php/content/copyContent";

            $.ajax({
                type: "post",
                dataType: "json",
                url: url,
                data: { ids: selectIds, catid: catid },
                success: function(data){
                    $("#editModal").modal("hide");

                    if(data.state == 1) {
                        bootbox.alert("操作成功。", function(){
                            window.location.reload();
                        });
                    }
                    else
                    {
                        bootbox.alert("操作失败，请稍后重试！");
                    }
                }
            });
        });

        //文章移动 or 复制
        $("#op-move").click(function(){
            var btnTxt = "移动";
            opNow = OP_MOVE;
            opContent(btnTxt);
        });
        $("#op-copy").click(function(){
            var btnTxt = "复制";
            opNow = OP_COPY;

            opContent(btnTxt);
        });

        //文章发布 or 取消发布
        $("#op-pub").click(function(){
            var btnTxt = "发布";
            opContentState(PUB, btnTxt, OP_PUB);
        });
        $("#op-cpub").click(function(){
            var btnTxt = "下线";
            opContentState(CPUB, btnTxt, OP_PUB);
        });

        //文章推广 or 取消推广
        $("#op-tg").click(function(){
            var btnTxt = "推广";
            opContentState(TG, btnTxt, OP_TG);
        });
        $("#op-ctg").click(function(){
            var btnTxt = "取消推广";
            opContentState(CTG, btnTxt, OP_TG);
        });

        /********************************筛选*****************************/
        $("#sxContent").click(function(){
            $("#searchModal2").modal("show");
        });
        $('#export').click(function(){
            $('#expModal').modal('show');
//
        });
        $('#doexp').click(function(){
            window.location.href = window.location.href+'/exp/1';
        });

    });

    /**
     * 移动或者复制文章
     * @param btnTxt 操作的名称
     */
    function opContent(btnTxt){
        selectIds = getSelection();
        if(!selectIds || selectIds.length < 1){
            bootbox.alert("请选择要" + btnTxt + "的文章！");
            return;
        }

        $("#selectSubmit").text(btnTxt);
        $("#myModalLabel").text(btnTxt + "文章");

        $("#editModal").modal("show");
        $("#moveWeb").change();
    }

    /**
     * 发布，下线，推广，取消推广文章
     * @param state 发布，下线，推广，取消推广
     * @param btnTxt 操作的名称
     * @param type  操作的类型【发布|推广】
     */
    function opContentState(state, btnTxt, type){
        selectIds = getSelection();
        if(!selectIds || selectIds.length < 1){
            bootbox.alert("请选择要" + btnTxt + "的文章！");
            return;
        }

        var url = "/admin.php/content/tgContent";
        if(type == OP_PUB){
            url = '/admin.php/content/pubContent';
        }

        $.ajax(
            {
                url: url,
                data: {ids: selectIds, state: state},
                type: "post",
                dataType: 'json',
                success: function (data) {
                    if (data.state == 1) {
                        bootbox.alert("操作成功。", function(){
                            window.location.reload();
                        });
                    } else {
                        bootbox.alert("操作失败，请稍后重试！");
                    }
                }
            });
    }

    /**
     * 菜单联动状态改变
     * @param selectId 下拉框ID
     * @param parentDivId   上级DIV ID
     * @param options   下拉框选项
     */
    function changeSelectOptions(selectId, parentDivId, options, hideDiv){
        var ops = "";

        for(var ob in options){
            ops += "<option value=" + options[ob].id + ">" + options[ob].title + "</option>";
        }

        if(ops != "" && ops != "<option value=-1>-- 全部 --</option>") {
            $("#"+parentDivId).show();
            $("#"+selectId).empty().html(ops).change();
        }
        else{
            for(var index = 0; index < hideDiv.length; index ++){
                $("#" + hideDiv[index]).hide();
            }
            $("#" + parentDivId).hide();
        }
    }

    /**
     * 获取选择的行
     * @returns {Array} 选中行ID
     */
    function getSelection(){
        var ids = [];
        $('#table').find("[name='id[]']").each(function () {
            if ($(this).prop("checked")) {
                ids.push($(this).val());
            }
        });

        return ids;
    }

    /**
     * 获取联动菜单选择的值
     */
    function getSelectedCatid(){
        var catid = -1;
        if(!$("#sj-cat-div").is(":hidden")){
            catid = $("#sj-cat").val();
        }
        else if(!$("#ej-cat-div").is(":hidden")){
            catid = $("#ej-cat").val();
        }
        else if(!$("#yj-cat-div").is(":hidden"))
        {
            catid = $("#yj-cat").val();
        }

        return catid;
    }

})();

/**
 * 点击推广事件
 * @param id
 * @param tg
 */
function dotuiguang(id, tg) {
    $.ajax({
        url: '/admin.php/Content/settg',
        data: {id: id, tg: tg},
        type: "post",
        success: function(data){
            if(data == 1){
                window.location.reload();
            }
        }
    });
}

/**
 * 点击发布事件
 * @param id
 * @param state
 */
function dopub(id, state) {
    $.ajax({
        url: '/admin.php/Content/isState',
        data: {id: id, state: (-1 - state)},
        type: "get",
        success: function(data){
            if(data == 1){
                window.location.reload();
            }
        }
    });
}

/**
 * 关闭筛选模态框
 */
function closeSx(){
    $("#searchModal2").modal("hide");
}