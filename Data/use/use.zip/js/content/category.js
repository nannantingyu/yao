/**
 * Created by yangmingming on 2016/1/12.
 */
var catManager = (function(){

    var allCat = [],    //所有的文章分类
        yjcatMenu = [], //一级文章分类
        ejcatMenu = [], //二级文章分类
        sjcatMenu = [], //三级文章分类
        prefix = 'a',
        baseurl = '/admin.php/content/lists/',
        iniCatid = -1;

    /**
     * 获取所有的分类
     */
    var getAllCategories = function(dfd){
        $.ajax({
            url: "/admin.php/content/getCatgories",
            type: "post",
            dataType: "json",
            success: function(data){
                allCat = data;
                dfd.resolve();
            }
        });
    };

    /**
     * 分类的初始化操作
     * @returns {*}
     */
    var init = function(catid){
        var dfd = $.Deferred();
        iniCatid = catid;
        getAllCategories(dfd);
        return dfd;
    }

    /**
     * 获取分类的面板，列出全部的分类
     * @param ini_self 是否勾选只显示我发布的文章
     * @param ini_status 筛选的文章状态
     */
    var getCatPanel = function(ini_self, ini_status){
        var style= 'font-size: 16px; color: orange; font-weight: bold;';
            param = {
                self: ini_self,
                state: ini_status
            },
            href = createUrl(param);
        var hjlinks = getAllLinks("hj", false, href)
                + '<p><a style="' + style + '" href="' + href + 'typeweb/hj">国鑫黄金</a></p>',
            shlinks = getAllLinks("sh", true, href)
                + '<p><a style="' + style + '" href="' + href + 'typeweb/hj">国鑫石化</a></p>',
                jflinks = getAllLinks("jf", true, href)
                + '<p><a style="' + style + '" href="' + href + 'typeweb/jf">国鑫金服</a></p>';
        return {
            hj: hjlinks,
            sh: shlinks,
            jf:jflinks
        };
    }

    /**
     * 生成分类列表的样式
     * @param typeweb
     * @param newline
     * @returns {string}
     */
    var getAllLinks = function(typeweb, newline, href){
        var html = "",
            style = "",
            lineEnd = newline ? '</p>' : '',
            lineStart = newline ? '<p style="padding-left: 25px;">' : '';

        for(var yj in yjcatMenu) {
            if (yjcatMenu[yj]["typeweb"] == typeweb) {
                var cat1 = yjcatMenu[yj]['id'],
                    title1 = yjcatMenu[yj]['title'];
                style = getLinkStyle(cat1, "blue");

                html += '<p><a href="' + href + 'catid/' + cat1 + '"' + style + '>' + title1 + '</a>' + lineEnd;

                for (var er in ejcatMenu[prefix + cat1]) {
                    var cat2 = ejcatMenu[prefix + cat1][er]['id'],
                        title2 = ejcatMenu[prefix + cat1][er]["title"];

                    html += lineStart;
                    style = getLinkStyle(cat2, "green");
                    html += '&nbsp;<a href="' + href + 'catid/' + cat2 + '"' + style + '>' + title2 + '</a>&nbsp;';

                    for (var sj in sjcatMenu[prefix + cat2]) {
                        var cat3 = sjcatMenu[prefix + cat2][sj]["id"],
                            title3 = sjcatMenu[prefix + cat2][sj]["title"];

                        style = getLinkStyle(cat3, "purple");

                        html += '&nbsp;<a href="' + href + 'catid/' + cat3 + '" ' + style + '>' + title3 + '</a>&nbsp;';
                    }
                    html += lineEnd;
                }
                html += '</p>';
            }
        }

        return html;
    };

    /**
     * 获取选中分类的链接列表（点击不跳转。执行方法）
     * @param typeweb
     * @param newline
     * @returns {string}
     */
    function getMethodLinks(typeweb, newline){
        var html = "",
            style = "",
            newe = newline?"</p>" : "",
            news = newline?'<p style="padding-left: 25px;">' : "";
        for(var yj in yjcatMenu) {
            if (yjcatMenu[yj]["typeweb"] == typeweb) {
                var cat1 = yjcatMenu[yj]['id'],
                    title1 = yjcatMenu[yj]['title'];
                style = getLinkStyle(cat1, "blue");

                html += '<p><a onclick="setCatNow(' + cat1 + ')" href="javascript:void(0);"' + style + '>' + title1 + '</a>' + newe;
                for (var er in ejcatMenu[prefix + cat1]) {
                    var cat2 = ejcatMenu[prefix + cat1][er]['id'],
                        title2 = ejcatMenu[prefix + cat1][er]["title"];

                    html += news;
                    style = getLinkStyle(cat2, "green");
                    html += '&nbsp;<a onclick="setCatNow(' + cat2 + ')" href="javascript:void(0);"' + style + '>'
                        + title2 + '</a>&nbsp;';

                    for (var sj in sjcatMenu[prefix + cat2]) {
                        var cat3 = sjcatMenu[prefix + cat2][sj]["id"],
                            title3 = sjcatMenu[prefix + cat2][sj]["title"];
                        style = getLinkStyle(cat3, "purple");

                        html += '&nbsp;<a onclick="setCatNow(' + cat3 + ')" href="javascript:void(0);"' + style + '>'
                            + title3 + '</a>&nbsp;';
                    }
                    html += newe;
                }
                html += '</p>';
            }
        }

        return html;
    }

    /**
     * 获取链接样式
     */
    function getLinkStyle(cid, color){
        var style = "";
        if(cid == iniCatid){
            style = ' style="color: red; font-weight: bold; font-size: 18px;" ';
        }
        else{
            style = ' style="color: '+color+';" ';
        }
        return style;
    }

    /**
     * 生成一二三级文章分类
     */
    function buildCatgory(){
        for(var index = 0; index < allCat.length; index ++){
            var catnow = allCat[index],
                pid = catnow.parent_id;

            if(catnow.parent_id == 1){
                yjcatMenu.push(catnow);
            }
            else if(isInArray(yjcatMenu, pid, "id") > -1)
            {
                if(!ejcatMenu[prefix + pid]){
                    ejcatMenu[prefix + pid] = [];
                }

                ejcatMenu[prefix + pid].push(catnow);
            }
            else{
                for(var ercat in ejcatMenu){
                    if(isInArray(ejcatMenu[ercat], pid, "id") > -1){
                        if(!sjcatMenu[prefix + pid]){
                            sjcatMenu[prefix + pid] = [];
                        }

                        sjcatMenu[prefix + pid].push(catnow);
                        break;
                    }
                }
            }
        }

        //return {yjcatMenu: yjcatMenu, ejcatMenu: ejcatMenu, sjcatMenu: sjcatMenu};

        yjcatMenu.sort(sortByLft);
        for(var er in ejcatMenu){
            ejcatMenu[er].sort(sortByLft);
        }
        for(var sr in sjcatMenu){
            sjcatMenu[sr].sort(sortByLft);
        }

        return [yjcatMenu, ejcatMenu, sjcatMenu];
    }

    /**
     * 数组中是否存在某一项
     * @param arr 查询的数组
     * @param value 查询的值
     * @param key 查询的键值
     * @returns 查询的值在数组中的位置
     */
    function isInArray(arr, value, key){
        if(!arr){
            return -1;
        }

        for(var o in  arr){
            if(arr[o][key] == value){
                return o;
            }
        }

        return -1;
    };

    /**
     * 获取分类树
     * @param catid 分类ID
     */
    function getLevelTree(catid){

        var selectLevel = [];
        //如果三级菜单存在
        for(var o in sjcatMenu){
            var index = -1;
            if((index = isInArray(sjcatMenu[o], catid, "id")) > -1){
                selectLevel[3] = {catid: catid, name: sjcatMenu[o][index]['title']};
                catid = sjcatMenu[o][index]["parent_id"];
            }
        }
        for(var o in ejcatMenu){
            var index = -1;
            if((index = isInArray(ejcatMenu[o], catid, "id")) > -1){
                selectLevel[2] = {catid: catid, name: ejcatMenu[o][index]['title']};
                catid = ejcatMenu[o][index]["parent_id"];
            }
        }
        if((index = isInArray(yjcatMenu, catid, "id")) > -1){
            selectLevel[1] = {catid: catid, name: yjcatMenu[index]['title']};
            selectLevel[0] = {typeweb: yjcatMenu[index]['typeweb']};
        }

        return selectLevel;
    }

    /**
     * 根据lft排序的回调函数
     * @param menu1
     * @param menu2
     * @returns {boolean}
     */
    function sortByLft(menu1, menu2){
        return menu1.lft > menu2.lft;
    }

    /**
     * 获取面包屑导航
     */
    function getCrumb(param, selectLevel){
        var href = "",
            crumb = "";

        if(selectLevel[1]){
            param.catid = selectLevel[1].catid;
            href = createUrl(param);

            crumb += '<li><a href="' + href + '">' + selectLevel[1].name + "</a></li>";
        }
        if(selectLevel[2]){
            param.catid = selectLevel[2].catid;
            href = createUrl(param);

            crumb += '<li><a href="' + href + '">' + selectLevel[2].name + "</a></li>";
        }
        if(selectLevel[3]){
            param.catid = selectLevel[3].catid;
            href = createUrl(param);

            crumb += '<li><a href="' + href + '">' + selectLevel[3].name + "</a></li>";
        }

        return crumb;
    }

    /**
     * 生成url链接
     * @param param 参数
     */
    function createUrl(param){
        var url = "";
        for(var obj in param){
            if(param[obj]){
                url += obj + "/" + param[obj] + "/";
            }
        }

        return baseurl + url;
    }

    return {
        init: init,
        getCatPanel: getCatPanel,
        getMethodLinks: getMethodLinks,
        buildCatgory: buildCatgory,
        createUrl: createUrl,
        getLevelTree: getLevelTree,
        getCrumb: getCrumb,
        yjcatMenu: yjcatMenu,
        ejcatMenu: ejcatMenu,
        sjcatMenu: sjcatMenu
    }
})();
