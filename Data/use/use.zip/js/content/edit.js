var catNow = -1;
var editModel = (function () {
    var yjcatMenu = [],
        ejcatMenu = [],
        sjcatMenu = [],
        selectLevel = [],
        contentID = null,
        contentCatID = null,
        contentTypeWeb = null,
        ctypes = {0: "文章", 1: "单页", 2: "视频"}
        tw = {hj: "国鑫黄金", sh: "国鑫石化", dsj: "财经大事件",jf:'国鑫金服'};

    var timePreg = /^((((1[6-9]|[2-9]\d)\d{2})-(0?[13578]|1[02])-(0?[1-9]|[12]\d|3[01]))|(((1[6-9]|[2-9]\d)\d{2})-(0?[13456789]|1[012])-(0?[1-9]|[12]\d|30))|(((1[6-9]|[2-9]\d)\d{2})-0?2-(0?[1-9]|1\d|2[0-8]))|(((1[6-9]|[2-9]\d)(0[48]|[2468][048]|[13579][26])|((16|[2468][048]|[3579][26])00))-0?2-29-)) (20|21|22|23|[0-1]?\d):[0-5]?\d:[0-5]?\d$/;

    var editor = CodeMirror.fromTextArea(document.getElementById("area-source"), {
        lineNumbers: true,
        mode: "htmlmixed",
        styleActiveLine: true,
        matchBrackets: true,
        extraKeys: {
            "F11": function (cm) {
                cm.setOption("fullScreen", !cm.getOption("fullScreen"));
            },
            "Esc": function (cm) {
                if (cm.getOption("fullScreen")) cm.setOption("fullScreen", false);
            }
        }
    });
    CodeMirror.commands["selectAll"](editor);
    editor.setSize(960, 379);

    var ue = UE.getEditor('content', {
        theme: "default", //皮肤
        lang: "zh-cn", //语言
        catchRemoteImageEnable: false,
        initialFrameWidth: 960, //初始化编辑器宽度,默认800
        initialFrameHeight: 320
    });

    catNow = $("#contentCatId").val();
    contentTypeWeb = $("#contentTypeweb").val();

    $(function () {

        //获取文章ID
        contentID = $("#contentId").val();

        //获取文章分类的menu
        catManager.init(contentID).done(function(){
            catManager.buildCatgory();
            var hjlinks = catManager.getMethodLinks("hj", false),
                shlinks = catManager.getMethodLinks("sh", true);
                jflinks = catManager.getMethodLinks("jf", true);
            $("#hj").html(hjlinks);
            $("#sh").html(shlinks);
            $("#jf").html(jflinks);

            if(catNow){
                selectLevel = catManager.getLevelTree(catNow);
            }

            if (!contentID) {
                $('#datetimepicker').val(getNow());
                $('#xreference').val("国鑫黄金");
                $('#btn-edit-cat').text("选择分类");
            }
            else {
                $("#subTitle").text("编辑文章");
            }

            if(catNow != -1){
                bindCat(selectLevel);
            }
        });

        $("#contenttype").change(function () {
            var ctype = $(this).val();
            $("#myTab li").removeClass("active");
            $("#myTab li:eq(" + ctype + ")").addClass("active");
            $("#myTabContent").children("div").removeClass("active").removeClass("in");
            $("#myTabContent").children("div:eq(" + ctype + ")").addClass("active").addClass("in");
        });

        //格式化按钮
        $("#btn-format").click(formatValue);
        //压缩代码按钮
        $("#btn-compress").click(compressValue);
        //提交按钮
        $("#btn-commit").click(commitEdit);
        //修改分类
        $("#btn-edit-cat").click(function(){
            $("#catModal2").modal("show");
        });
    });

    /**
     * 绑定分类面包屑
     * @param selectLevel
     */
    function bindCat(selectLevel){
        var catmenus = [];
        for (var o in selectLevel) {
            if (selectLevel[o]['name']) {
                catmenus.push(selectLevel[o]['name']);
            }
        }
        $("#cat-p").html(tw[selectLevel[0]["typeweb"]] + "&nbsp;&nbsp;/&nbsp;&nbsp;" + catmenus.join("&nbsp;&nbsp;/&nbsp;&nbsp;"));
        $('#a' + selectLevel[0]['typeweb']).tab('show');
    }

    /**
     * 改变当前的分类
     * @param catid 分类ID
     */
    this.changeCatNow = function(catid){
        catNow = catid;
        selectLevel = catManager.getLevelTree(catNow);
        bindCat(selectLevel);
        $("#catModal2").modal("hide");
    };

    /**
     * 获取当前时间
     * @returns {string}
     */
    function getNow() {
        var now = new Date();
        return now.getFullYear() + "-" + addZero(now.getMonth() + 1, 2) + "-" + addZero(now.getDate(), 2) + " " +
            addZero(now.getHours(), 2) + ":" + addZero(now.getMinutes(), 2) + ":" + addZero(now.getSeconds(), 2);
    }

    /**
     * 自动补零
     * @param num
     * @returns {*}
     */
    function addZero(num) {
        return num > 9 ? num : "0" + num;
    }

    /**
     * 获取表单值
     */
    function getFormValue() {
        var title = contentForm.title.value,
            created_by_alias = contentForm.created_by_alias.value,
            metakey = contentForm.metakey.value,
            metadesc = $("#metadesc").val(),
            contenttype = contentForm.contenttype.value,
            introtext = null,
            imgurl = contentForm.imgurl.value,
            created = contentForm.created.value,
            xreference = contentForm.xreference.value,
            hits = contentForm.hits.value,
            sequence = contentForm.sequence.value,
            urla = contentForm.urla.value,
            id = contentForm.id.value;

        var state = ($('#state').is(':checked')) ? 1 : -2;

        msg = null;
        if (!title) {
            msg = "请输入文章标题！";
        }
        else if(!timePreg.test($('#datetimepicker').val())){
            msg = '发布时间格式不正确，请按照 yyyy-mm-dd hh:ii:ss 的格式重新输入！';
        }
        else {
            if (contenttype == 0) {
                introtext = UE.getEditor('content').getContent();
            }
            else if (contenttype == 1) {
                introtext = editor.getValue();
            }
            else if (contenttype == 2) {
                introtext = '<p style="text-align: center">'
                    + '<embed src="/swf/mediaplayer.swf" height="480" width="640" menu="true" loop="true" play="true"'
                    + ' autostart="true" allowfullscreen="true" flashvars="file='
                    + contentForm.introtextVideo.value + '&width=640&height=480&autostart=true" wmode="transparent"'
                    + 'type="application/x-shockwave-flash"></embed> </p>';
            }
        }

        if (msg) {
            bootbox.alert(msg);
            return null;
        }

        var contentT = $("#myTab>li.active>a").text();
        if (ctypes[contenttype] != contentT) {
            bootbox.alert("您选择的文章类型和编辑的文章类型不匹配，请重新选择或编辑！");
            return null;
        }
        if(!catNow || catNow == -1){
            bootbox.alert("请先选择文章分类，再保存！");
            return null;
        }

        return {
            id: id ? id : -1,
            catid: catNow,
            title: title,
            contenttype: contenttype,
            imgurl: imgurl,
            created_by_alias: created_by_alias,
            urla: urla,
            metadesc: metadesc,
            metakey: metakey,
            state: state,
            introtext: introtext,
            created: created ? created : null,
            xreference: xreference,
            hits: hits ? hits : 0,
            sequence: sequence ? sequence : 0
        }
    }

    /**
     * 提交修改
     */
    function commitEdit() {
        var formVal = getFormValue();
        if (formVal) {
            $.ajax({
                url: "/admin.php/content/editContent",
                data: formVal,
                type: 'post',
                dataType: 'json',
                success: function (data) {
                    if (data.state == 1) {
                        var param = {
                            catid: catNow
                        };

                        var msg = "添加成功！";
                        if (formVal.id != -1) {
                            msg = "修改成功！";
                        }

                        bootbox.alert(msg, function () {
                            window.location.href = catManager.createUrl(param);
                        });
                    }
                }
            });
        }
    }

    /**
     * 格式化代码
     */
    function formatValue() {
        var range = {from: editor.getCursor(true), to: editor.getCursor(false)};
        editor.autoFormatRange(range.from, range.to);
    }

    /**
     * 压缩代码
     */
    function compressValue() {
        var value = editor.getValue();
        value = value.replace(/(\r\n|\n|\r)/gm, '');
        value = value.replace(/(\s+\<)/gm, '<');
        value = value.replace(/(>\s+)/gm, '>');
        value = value.replace(/\s+/gm, " ");
        editor.setValue(value);
    }

    return {
        changeCatNow: changeCatNow
    }
})();

/**
 * 关闭筛选模态框
 */
function closeSx(){
    $("#catModal2").modal("hide");
}
/**
 * 设置当前分类
 * @param catid
 */
function setCatNow(catid){
    catNow == catid;
    editModel.changeCatNow(catid);
}