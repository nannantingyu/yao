var allData = [];

$(function(){
    loaddata();
});

function loaddata() {
    $.ajax({
        url: '/admin.php/keywords/getKeywords',
        data: {site: $("select[name='site']").val()},
        dataType: 'json',
        success: function(data){
            allData = data;
            initTable(data);
        }
    });
}

//初始化表格
function initTable(data)
{
    $("#tb-key").bootstrapTable("destroy");
    $("#tb-key").bootstrapTable({
        pagination: true,
        pageSize: 20,
        classes: 'table-striped',
        search: true,
        showColumns: true,
        locale: "zh-CN",
        columns: [
            {
                field: 'states',
                checkbox: true,
                width: '10%'
            },
            {
                field: 'id',
                title: '编号',
                width: '5%',
                sortable: true
            },
            {
                field: 'keywords',
                title: '关键词',
                width: '20%',
                sortable: true
            },
            {
                field: 'url',
                title: '链接',
                width: '30%',
                sortable: true
            },
            {
                field: 'is_link',
                title: '默认',
                formatter: showFormatter,
                width: '10%',
                sortable: true
            },
            {
                field: 'state',
                title: '状态',
                formatter: statesFormatter,
                width: '10%',
                sortable: true
            },
            {
                field: 'operate',
                title: '操作',
                formatter: operateFormatter,
                width: '15%'
            },
        ],
        data: data
    });
}

function operateFormatter(value, row, index) {
    return '<a onclick="deleteKeywords(' + row.id + ')" class="btn btn-danger">删除</a>'
        + '<a href="/admin.php/keywords/edit/id/' + row.id + '/" class="btn btn-info">编辑</a>';
};

function showFormatter(value, row, index) {
    return '<a onclick="toggleState(this,'+row.id+',' + row.is_link + ', \'is_link\', \'默认\', \'非默认\')" class="btn' + (value == 1?' btn-success">默认':' btn-primary">非默认') + '</a>';
};

function statesFormatter(value, row, index) {
    return '<a onclick="toggleState(this,'+row.kid+',' + row.state + ', \'state\', \'发布\', \'不发布\')" class="btn' + (value == 1?' btn-success">发布':' btn-primary">不发布') + '</a>';
};

/**
 * 改变状态
 * @param obj
 * @param id
 * @param state
 */
function toggleState(obj, id, state, key, showTxt, hideTxt){
    var btnShow = $(obj),
        url = '/admin.php/keywords/changeISLink';

    if(key == 'state'){
        url = '/admin.php/keywords/changeState';
    }

    $.ajax({
        url: url,
        data: {id: id, state: 1 - state, sid: $("select[name='site']").val()},
        dataType: 'json',
        type: 'post',
        success: function(data){
            if(data.state == 1)
            {
                if(state == 0)
                {
                    btnShow.removeClass("btn-primary").addClass("btn-success").text(showTxt);
                }
                else
                {
                    btnShow.removeClass("btn-success").addClass("btn-primary").text(hideTxt);
                }

                $(obj).attr('onclick', 'toggleState(this, '+id+','+(1-state)+',"'+key+'","'+showTxt+'","'+hideTxt+'")');

                changeRow(id, key, 1-state);
                bootbox.alert("修改成功！");
            }
            else
            {
                bootbox.alert('修改失败，原因：' + data.msg);
            }
        }
    });
}

/**
 * 删除关键词
 * @param ids
 */
function deleteKeywords(ids){
    var selectedId = [];

    if(!ids){
        var selectedData = $("#tb-key").bootstrapTable("getSelections");
        if(selectedData.length < 1)
        {
            bootbox.alert("请选择要删除的关键词！");
            return;
        }

        $.each(selectedData, function(index, data){
            selectedId.push(data.id);
        });
    }
    else
    {
        selectedId.push(ids);
    }

    $.ajax({
        url: '/admin.php/keywords/delKeywords',
        data: {ids: selectedId},
        dataType: 'json',
        type: 'post',
        success: function(data){
            if(data.state == 1)
            {
                for(var o in selectedId){
                    deleteRow(selectedId[o]);
                }
                bootbox.alert("删除成功！");
                initTable(allData);
            }
        }
    });
}

/**
 * 删除行
 * @param kid
 */
function deleteRow(id){
    for(var index = 0; index < allData.length; index ++){
        if(allData[index]['id'] == id){
            allData.splice(index, 1);
            break;
        }
    }
}

//改变行的值
function changeRow(id, key, val){
    for(var index = 0; index < allData.length; index ++){
        if(allData[index]['id'] == id){
            allData[index][key] = val;
            break;
        }
    }
}

function copyTo(sid){
    var selectedData = $("#tb-key").bootstrapTable("getSelections");
    if(selectedData.length < 1)
    {
        bootbox.alert("请选择要复制的关键词！");
        return;
    }

    var nowSite = $("select[name='site']").val();
    if(sid == nowSite){
        bootbox.alert("不能复制当前站点！");
        return;
    }

    var selectedId = [];
    $.each(selectedData, function(index, data){
       selectedId.push(data.id);
    });

    $.ajax({
        url: '/admin.php/keywords/copyTo',
        data: {sid: sid, ids: selectedId},
        dataType: 'json',
        type: 'get',
        success: function(data){
            if(data.state == 1)
            {
                bootbox.alert("复制成功！");
            }
            else
            {
                bootbox.alert(data.msg);
            }
        }
    });
}