var allData = [];
var allSite = [];
var obj = null;

$(function(){
    //loaddata();

    $.ajax({
        url: '/admin.php/keywords/getAllSites',
        dataType: 'json',
        success: function(data){
            allSite = data;
        }
    });

    $('#toolbar').find('select').change(function () {
        $("#tb-allkeys").bootstrapTable('refreshOptions', {
            exportDataType: $(this).val()
        });
    });

});

function loaddata() {
    $.ajax({
        url: '/admin.php/keywords/getAllKeys',
        data: {site: $("select[name='site']").val()},
        dataType: 'json',
        success: function(data){
            allData = data;
            initTable(data);
        }
    });
}

function statesFormatter(value, row, index) {
    return '<a onclick="toggleState(this,'+row.kid+',' + row.state + ', \'state\', \'发布\', \'不发布\')" class="btn' + (value == 1?' btn-success">发布':' btn-primary">不发布') + '</a>';
}

function operateFormatter(value, row, index) {
    //return '<a onclick="deleteKeywords(' + row.kid + ')" class="btn btn-danger">删除</a>&nbsp;&nbsp;'
    return '<a href="/admin.php/keywords/edit/kid/' + row.kid + '/" class="btn btn-info">编辑</a>';
};

function siteFormatter(value, row, index) {
    return '<a href="javascript:void(0)" onclick="changeSite(this, '+row.kid+', \'' + row.site + '\')">' + value +'</a>';
}

function changeSite(o, kid, site){
    $('#siteModal').modal('show');
    var sites = site.split(',');
    $('.selectpicker').selectpicker('val', sites);
    $('#kid').val(kid);
    obj = o;
    $(o).unbind('');
}

/**
 * 提交修改站点
 */
function submitSiteChange(){
    var sites = $('.selectpicker').selectpicker('val'),
        kid = $('#kid').val();
    $.ajax({
        url: '/admin.php/keywords/changeSite',
        data: {kid: kid, sites: sites},
        type: 'post',
        dataType: 'json',
        success: function (data) {
            $.when($('#siteModal').modal('hide')).done(function () {
                bootbox.alert('修改成功！', function() {
                    var sitename = [];
                    for (var o in sites) {
                        sitename.push(allSite[sites[o]]);
                    }

                    var newName = sitename.join('，');
                    changeRow(kid, 'sitename', newName);
                    $(obj).attr('onclick', 'changeSite(this, ' + kid + ', \'' + sites.join(',') + '\')').text(newName);
                });
            });
        }
    });
}

/**
 * 改变状态
 * @param obj
 * @param id
 * @param state
 */
function toggleState(obj, id, state, key, showTxt, hideTxt){
    var btnShow = $(obj),
        url = '/admin.php/keywords/changeISLink';

    if(key == 'state'){
        url = '/admin.php/keywords/changeState';
    }

    $.ajax({
        url: url,
        data: {id: id, state: 1 - state, sid: $("select[name='site']").val()},
        dataType: 'json',
        type: 'post',
        success: function(data){
            if(data.state == 1)
            {
                if(state == 0)
                {
                    btnShow.removeClass("btn-primary").addClass("btn-success").text(showTxt);
                }
                else
                {
                    btnShow.removeClass("btn-success").addClass("btn-primary").text(hideTxt);
                }

                $(obj).attr('onclick', 'toggleState(this, '+id+','+(1-state)+',"'+key+'","'+showTxt+'","'+hideTxt+'")');

                changeRow(id, key, 1-state);
                bootbox.alert("修改成功！");
            }
            else
            {
                bootbox.alert('修改失败，原因：' + data.msg);
            }
        }
    });
}

//改变行的值
function changeRow(id, key, val){
    for(var index = 0; index < allData.length; index ++){
        if(allData[index]['id'] == id){
            allData[index][key] = val;
            break;
        }
    }
}

/**
 * 删除关键词
 * @param ids
 */
function deleteKeywords(ids){
    var selectedId = [];

    if(!ids){
        var selectedData = $("#tb-allkeys").bootstrapTable("getSelections");
        if(selectedData.length < 1)
        {
            bootbox.alert("请选择要删除的关键词！");
            return;
        }

        $.each(selectedData, function(index, data){
            selectedId.push(data.kid);
        });
    }
    else
    {
        selectedId.push(ids);
    }

    $.ajax({
        url: '/admin.php/keywords/delKeywords',
        data: {ids: selectedId},
        dataType: 'json',
        type: 'post',
        success: function(data){
            if(data.state == 1)
            {
                for(var o in selectedId){
                    deleteRow(selectedId[o]);
                }
                bootbox.alert("删除成功！");
                $("#tb-allkeys").bootstrapTable('remove', {
                    field: 'kid',
                    values: selectedId
                });
            }
        }
    });
}

/**
 * 删除行
 * @param kid
 */
function deleteRow(id){
    for(var index = 0; index < allData.length; index ++){
        if(allData[index]['kid'] == id){
            allData.splice(index, 1);
            break;
        }
    }
}