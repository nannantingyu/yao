/**
 * 行情分析JS
 * @author yangmm
 */
var self = this;
var combineName = $("#tx-combined-name");
var exchange = $("#exchange");
var msp = $("#s-modify-sp");
var mspname = $("#tx-modify-name");
var mspcode = $("#tx-modify-code");
self.allSpecies = [];
self.allExchange = [];
self.allTypeSpecies = [];
self.selectCid = null;
self.selectId = null;
self.selectPid = null;
self.selectLevel = null;
self.isOnlyShowed = false;

$(function(){
	
	self.selectCid = $("input[name='t-cid']").val();

	exchange.change(function(){
		refreshTable($(this).val());
	});
	
	$("#ck-isshow").change(function(){
		self.isOnlyShowed = $(this).prop("checked");
		refreshTable(self.selectCid);
	});
	loadData();
});

//初始化时加载数据
function loadData()
{
	$.ajax({
    	url: "/quotation/getAllSpeciesAjax",
    	dataType: "json",
    	data: {"ajax": true},
    	type: "post",
    	success: function(data){
    		
    		self.allExchange = data.exchange;
    		self.allSpecies = data.species;
    		
    		self.allTypeSpecies = [];
    		for(var index = 0; index < self.allExchange.length; index ++)
    		{
    			self.allTypeSpecies.push({"id":self.allExchange[index].id, "data":findData(self.allExchange[index].id, 1)});
    		}
    		
    		
    		var html = "";
    		for(var index = 0; index < self.allExchange.length; index ++){
    			html += '<option value=' + self.allExchange[index].id + '>' + self.allExchange[index].name + '</option>';
    		}
    		exchange.empty().append(html);
    		
    		initTable();
    	}
    });
}

/**
 * 筛选出同一交易所下的同一级别的品种
 * @param exId
 * @param level
 * @returns {Array}
 */
function findData(exId, level)
{
	var tableData = [];
	for(var p in self.allSpecies)
	{
		if(p == exId)
		{
			for(var index = 0; index < self.allSpecies[p].length; index ++)
			{
				if(self.allSpecies[p][index].level == level)
				{
					tableData.push(self.allSpecies[p][index]);
				}
			}
			break;
		}
	}
	
	return tableData;
}

//刷新表
function refreshTable(exId)
{
	self.selectCid = exId;
	var index = findSelectedData(exId);
	var tableData = self.allTypeSpecies[index].data;
	
	var tdata = [];
	//如果只查看显示的品种
	for(var i = 0, max = tableData.length; i < max; i++)
	{
		if(!self.isOnlyShowed || (tableData[i].isshow == 1))
		{
			tdata.push(tableData[i]);
		}
	}
	
	createPsp(tableData);
	$("#tb-speices").bootstrapTable("load", tdata);
};

//修改品种的modal的下拉框绑定
function createPsp(tableData)
{
	var html = "<option value=0>无</option>";
	for(var i = 0, max = tableData.length; i < max; i++)
	{
		html += "<option value="+tableData[i].id+">"+tableData[i].name+"</option>";
	}
	msp.empty().html(html);
}

//改变品种是否显示或隐藏
function toggleState(obj, id, cid)
{
	var btnShow = $(obj);
	var isshow = btnShow.hasClass("btn-primary")? 0 : 1;
	
	$.ajax({
		url: '/quotation/changeState',
		data: {id: id, isshow: 1-isshow},
		dataType: 'json',
		type: 'post',
		success: function(data){
			if(data.state == 1)
			{
				var st = "";
				if(isshow == 0)
				{
					st = "显示";
					btnShow.removeClass("btn-primary").addClass("btn-success").text("显示");
				}
				else
				{
					st = "隐藏";
					btnShow.removeClass("btn-success").addClass("btn-primary").text("隐藏");
				}

				var row = findRow(cid, id);
				self.allTypeSpecies[row.pindex].data[row.index].isshow = 1-isshow;
				
				bootbox.alert("该品种已设置为" + st + "。");
				
			}
			else if(data.state == 0)
			{
				bootbox.alert("修改失败！原因：" + data.msg);
			}
		}
	});
}

//根据ID查找选中行数据
function findSelectedData(id)
{
	for(var index = 0; index < self.allTypeSpecies.length; index ++)
	{
		if(self.allTypeSpecies[index].id == id)
		{
			return index;
		}
	}
}

//查找table的行
function findRow(cid, id)
{
	var sdataIndex = findSelectedData(cid);
	var sdata = self.allTypeSpecies[sdataIndex].data;
	for(var index = 0; index < sdata.length; index ++)
	{
		if(sdata[index].id == id)
		{
			return {"pindex":sdataIndex, "index":index };
			break;
		}
	}
}

//初始化表格
function initTable()
{
	if(!self.selectCid || self.selectCid < 0){
		self.selectCid = self.allExchange[0].id;	
	}
	
	exchange.val(self.selectCid);
	
	var tableDataIndex = findSelectedData(self.selectCid);
	var tableData = self.allTypeSpecies[tableDataIndex].data;
	
	createPsp(tableData);

	//如果只查看显示的品种勾选
	var tdata = [];
	for(var i = 0, max = tableData.length; i < max; i++)
	{
		if(!self.isOnlyShowed || (tableData[i].isshow == 1))
		{
			tdata.push(tableData[i]);
		}
	}

	$("#tb-speices").bootstrapTable("destroy");
	$("#tb-speices").bootstrapTable({
		pagination: true,
		pageSize: 6,
		classes: 'table-striped',
		search: true,
		showColumns: true,
		locale: "zh-CN",
		columns: [
			{
			    field: 'state',
			    checkbox: true,
			    width: '10%'
			},
			{
		        field: 'id',
		        title: '编号',
		        width: '15%'
		    }, 
		    {
		        field: 'code',
		        title: 'Code',
		        width: '20%'
		    }, 
		    {
		        field: 'name',
		        title: '名称',
		        width: '20%'
		    },
		    {
				field: 'isshow',
				title: '显示/隐藏',
				formatter: showFormatter,
				width: '15%'
		    },
		    {
		    	field: 'operate',
		    	title: '操作',
		    	formatter: operateFormatter,
		    	width: '30%'
		    },
		    {
		    	field: 'cid',
		    	visible: false
		    },
		    {
		    	field: 'pid',
		    	visible: false
		    },
		    {
		    	field: 'level',
		    	visible: false
		    }
		    ],
	    data: tdata
	});
	
	$("#modal-table").bootstrapTable({
		classes: 'table-striped',
		locale: "zh-CN",
		columns: [
			{
			    field: 'select',
			    radio: true,
				title: '合并Code'
			},
			{
		        field: 'id',
		        title: '编号'
		    }, 
		    {
		        field: 'code',
		        title: 'Code'
		    }, 
		    {
		        field: 'name',
		        title: '名称'
		    },
		    {
		    	field: 'cid',
		    	visible: false
		    },
		    {
		    	field: 'pid',
		    	visible: false
		    },
		    {
		    	field: 'level',
		    	visible: false
		    }
		],
	    data: []
	});
}

function refreshData(){
	$.ajax({
		url: "/quotation/refreshData",
		type: "post",
		dataType: "json",
		success: function(data){
			if(data.state == 1){
				bootbox.alert("刷新成功！");
				loadData();
			}
			else
			{
				bootbox.alert("刷新失败！原因：" + data.msg);	
			}
		}
	});
};

function combine()
{
	var selectedData = $("#tb-speices").bootstrapTable("getSelections");
	if(selectedData.length < 2)
	{
		bootbox.alert("请选中至少两条数据进行合并！");
		return;
	}
	for(var index = 0; index < selectedData.length; index ++)
	{
		if(checkHasChild(selectedData[index].id))
		{
			bootbox.alert("不能合并这两条数据，【" +selectedData[index].name+"】有子品种存在！");
			return;
		}
	}
	selectedData[0].select = true;
	$("#modal-table").bootstrapTable("load", selectedData);
	$('#myModal').modal('show');
};

//点击模态框中的合并按钮
function runCombine()
{
	var selectedData = $("#modal-table").bootstrapTable("getData");

	var cname = combineName.val(); 
	if(!cname)
	{
		bootbox.alert("请输入合并后的品种名！");
		return;
	}
	
	//开始合并
	$.ajax({
		url: '/quotation/combineSpecies',
		data: {'cdata': selectedData, 'cname': cname},
		dataType: 'json',
		type: 'post',
		success: function(dt)
		{
			bootbox.alert("合并成功！");
			$('#myModal').modal('hide');

			var sdt = self.allTypeSpecies[findSelectedData(selectedData[0].cid)];
			for(var index = 0; index < selectedData.length; index ++)
			{
				for(var i = 0, max = sdt.data.length; i < max; i++)
				{
					if(sdt.data[i].id == selectedData[index].id)
					{
						sdt.data.splice(i, 1);
						break;
					}
				}
			}
			
			sdt.data.push({id:dt.addId, name:cname, level:1, isshow:true, pid:0, cid:selectedData[0].cid, code: dt.code });
			
			initTable();
		}
	});
}

function checkHasChild(id)
{
	for(var p in self.allSpecies)
	{
		for(var index = 0; index < self.allSpecies[p].length; index ++)
		{
			if(self.allSpecies[p][index].pid == id)
			{
				return true;
			}
		}
	}
	
	return false;
}

function editSpecies(id, level, name, code)
{
	mspname.val(name);
	mspcode.val(code);
	$("#editModal").modal("show");
	
	self.selectId = id;
	self.selectLevel = level;
}

function commitEdit()
{
	var tspname = mspname.val();
	var tspcode = mspcode.val();
	var tsp = msp.val();
	if(!tspname)
	{
		bootbox.alert("请输入修改的名称");
		return;
	}

	if(self.selectId == tsp){
		bootbox.alert("不能移动到自己分类下！请重新选择。");
		return;
	}

	$.ajax({
		url: "/quotation/editSpecies",
		data: {id: self.selectId, pid: tsp, name: tspname, level:self.selectLevel, code:tspcode},
		type: 'post',
		dataType: "json",
		success: function(data){
			
			if(tsp != 0)
			{
				var sdt = self.allTypeSpecies[findSelectedData(self.selectCid)];
				for(var i = 0, max = sdt.data.length; i < max; i++)
				{
					if(sdt.data[i].id == self.selectId)
					{
						sdt.data.splice(i, 1);
						break;
					}
				}
			}
			else
			{
				var row = findRow(self.selectCid, self.selectId);
				var dataInList = self.allTypeSpecies[row.pindex].data[row.index];
				dataInList.name = tspname;
				dataInList.code = tspcode;
			}
			
			refreshTable(self.selectCid);
			bootbox.alert("修改成功！");
			$("#editModal").modal("hide");
			
		}
	});
}

//根据交易所的id找名称
function findExNameById(id)
{
	for(var index = 0; index < self.allExchange.length; index++){
		if(self.allExchange[index].id == id){
			return self.allExchange[index].name;
		}
	}
}

function operateFormatter(value, row, index) {
    return '<a class="btn btn-warning" href="javascript:void(0)" onclick="editSpecies('+row.id+','+row.level+',\''+row.name+'\',\''+row.code+'\')" title="编辑">编辑</a>&nbsp;&nbsp;<a class="btn btn-info" href="/quotation/subtype/pid/'+row.id+'/pname/'+row.name+'/cid/'+row.cid+'/cname/'+findExNameById(row.cid)+'" title="子分类">子分类</a>';
};
function showFormatter(value, row, index) {
	return '<a onclick="toggleState(this,'+row.id+', '+row.cid+')" class="btn' + (value == 1?' btn-success">显示':' btn-primary">隐藏') + '</a>';
};