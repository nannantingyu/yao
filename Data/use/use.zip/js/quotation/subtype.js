/**
 * 子分类列表
 */

var pid = null;
var cid = null;
var pname = null;
var cname = null;
var tbSub = $("#sub-table");
var subModifyName = $("#tx-modify-name-sub");
var allSubSpecies = [];
var selectId = null;
var isOnlyShowed = false;

$(function(){
	$("#sub-ck-isshow").change(function(){
		isOnlyShowed = $(this).prop("checked");
		refreshTable();
	});
	
	pid = $('input[name="t-pid"]').val();
	cid = $('input[name="t-cid"]').val();
	pname = $('input[name="t-pname"]').val();
	cname = $('input[name="t-cname"]').val();
	loadData();
});


function loadData()
{
	$.ajax({
		url: "/quotation/getSubtype",
		data: {pid: pid},
		dataType: "json",
		type: "post",
		success: function(data){
			allSubSpecies = data;
			initTable();
		}
	});
};

//初始化表格
function initTable()
{
	tbSub.bootstrapTable("destroy");
	tbSub.bootstrapTable({
		pagination: true,
		pageSize: 4,
		classes: 'table-striped',
		search: true,
		showColumns: true,
		columns: [
			{
			    field: 'state',
			    checkbox: true
			},
			{
		        field: 'id',
		        title: '编号'
		    }, 
		    {
		        field: 'code',
		        title: 'Code'
		    }, 
		    {
		        field: 'name',
		        title: '名称'
		    },
		    {
				field: 'isshow',
				title: '显示/隐藏',
				formatter: showFormatter
		    },
		    {
		    	field: 'operate',
		    	title: '操作',
		    	formatter: operateFormatter
		    },
		    {
		    	field: 'cid',
		    	visible: false
		    },
		    {
		    	field: 'pid',
		    	visible: false
		    },
		    {
		    	field: 'level',
		    	visible: false
		    }
		    ],
	    data: allSubSpecies
	});
	
	$("#modal-table").bootstrapTable({
		classes: 'table-striped',
		columns: [
			{
			    field: 'state',
			    checkbox: true
			},
			{
		        field: 'id',
		        title: '编号'
		    }, 
		    {
		        field: 'code',
		        title: 'Code'
		    }, 
		    {
		        field: 'name',
		        title: '名称'
		    },
		    {
		    	field: 'cid',
		    	visible: false
		    },
		    {
		    	field: 'pid',
		    	visible: false
		    },
		    {
		    	field: 'level',
		    	visible: false
		    }
		],
	    data: []
	});
}

function editSpecies(id, name)
{
	selectId = id;
	subModifyName.val(name);
	$("#editModal").modal("show");
}

function toggleState(obj, id)
{
	var btnShow = $(obj);
	var isshow = btnShow.hasClass("btn-primary")? 0 : 1;
	
	$.ajax({
		url: '/quotation/changeState',
		data: {id: id, isshow: 1-isshow},
		dataType: 'json',
		type: 'post',
		locale: "zh-CN",
		success: function(data){
			if(data.state == 1)
			{
				var st = "";
				if(isshow == 0)
				{
					st = "显示";
					btnShow.removeClass("btn-primary").addClass("btn-success").text("显示");
				}
				else
				{
					st = "隐藏";
					btnShow.removeClass("btn-success").addClass("btn-primary").text("隐藏");
				}

				var index = findSubSpeciesIndex(id);
				allSubSpecies[index].isshow = 1-isshow;
				
				bootbox.alert("该品种已设置为" + st + "。");
				
			}
			else if(data.state == 0)
			{
				bootbox.alert("修改失败！原因：" + data.msg);
			}
		}
	});
}

function commitEdit()
{
	var tspname = subModifyName.val();
	if(!tspname)
	{
		bootbox.alert("请输入修改的名称");
		return;
	}
	
	$.ajax({
		url: "/quotation/editSubSpecies",
		data: {id: selectId, name: tspname},
		type: 'post',
		dataType: "json",
		success: function(data){
			
			allSubSpecies[findSubSpeciesIndex()].name = tspname;
			
			refreshTable();
			bootbox.alert("修改成功！");
			$("#editModal").modal("hide");
			
		}
	});
};

function quitNowType(id, name, pid)
{
	$.ajax({
		url: "/quotation/quitNowType",
		data: {id: id, pid: pid},
		type: 'post',
		dataType: "json",
		success: function(data){
			if(data.state == 1){
				allSubSpecies.splice(findSubSpeciesIndex(id), 1);
				
				bootbox.alert("【" + name + "】已经添加到一级分类下！");
				$("#editModal").modal("hide");
				refreshTable();
			}
			else
			{
				bootbox.alert("退出失败！原因：" + data.msg);
			}
		}
	});
}

function findSubSpeciesIndex(id)
{
	if(!id)
	{
		id = selectId;
	}
	
	for(var index = 0; index < allSubSpecies.length; index ++)
	{
		if(allSubSpecies[index].id == id)
		{
			return index;
		}
	}
}

function refreshTable()
{
	var tdata = [];
	for(var index = 0, max = allSubSpecies.length; index < max; index ++){
		if(!isOnlyShowed || (allSubSpecies[index].isshow == 1))
		{
			tdata.push(allSubSpecies[index]);
		}
	}
	tbSub.bootstrapTable("load", tdata);
};

function operateFormatter(value, row, index) {
    return '<a class="btn btn-warning" href="/quotation/addQuo/pid/'+pid+'/cid/'+cid+'/pname/'+pname+'/cname/'+cname+'/id/'+row.id+'/name/'+row.name+'" title="编辑">编辑</a>&nbsp;&nbsp;<a class="btn btn-info" onclick="quitNowType('+row.id+',\''+row.name+'\','+row.pid+')" href="javascript:void(0)" title="退出">退出</a>';
};
function showFormatter(value, row, index) {
	return '<a onclick="toggleState(this,'+row.id+', '+row.cid+')" class="btn' + (value == 1?' btn-success">显示':' btn-primary">隐藏') + '</a>';
};