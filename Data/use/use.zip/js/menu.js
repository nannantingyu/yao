function getpardata(type, parent_id, l, htmlid){
    if($('#'+htmlid).attr('red')!=1){ 
        if (type){
            if (parent_id){
                if (l == 1){
                    var leftkong = '&nbsp;&nbsp;&nbsp;&nbsp;';
                    var level = 2;
                }
                if (l == 2){
                    var leftkong = '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;';
                    var level = 3;
                }
                $.get('/admin.php/menu/getparentdata', {menutype:type, parent_id:parent_id}, function(d){
                    if (d != 'null'){
                        d = eval("(" + d + ")");
                        var html = '';
                        $('#'+htmlid).attr('red','1');
                        $.each(d, function(k, v){
                            html = html + '<tr par='+parent_id+' id="tr' + v.id + '">';
                                    html = html + '<td>' + v.id + '</td>';
                                    html = html + '<td></td>';
                                    html = html + '<td onclick="getpardata(\'' + type + '\',' + v.id + ',' + level + ',\'tr' + v.id + '\')">' + leftkong + v.title + '</td>';
                                    html = html + '<td>' + v.path + '</td>';
                                    html = html + '<td><a target="_blank" href="/admin.php/menu/seoedit/id/' + v.id + '" class="button bg-blue button-small">SEO修改</a></td>';
                                    html = html + '</tr>';
                            })
                            $('#' + htmlid).after(html);
                    }else{
                        alert('无下级菜单');
                    }
                })

            }
        }
    } 
}