var ini_status = "",
    ini_catid = "",    
    ini_keyword = "";
(function () {
    var selectIds = [];
    var PUB = 1,    //广告发布状态
        CPUB = -2;  //广告取消发布状态
    $(function () {
        ini_status = $("#hiddenstatus").val() || 1;
        ini_catid = $("#hidden-catid").val() || -1;       
        ini_keyword = $("#contentKeyword").val() || "";
        //发布状态
        $("#bannerState").change(function(){
           var option = $(this).val();
           var catid = $('#hidden-catid').val();
           
           var href = "/admin.php/banner/lists/";
           if(catid){
               href += 'catid/' + catid + "/";
           }
           href += "state/" + option;
           window.location.href = href;
        });
        $("#class_id").change(function(){
            var cvalue = $(this).val();          
            var href =  "/admin.php/banner/lists/catid/" + cvalue;
            window.location.href = href;
        });
        //搜索
        $("#btn-search").click(func1);      

        /***********************************编辑广告*********************************/
        //文章发布 or 取消发布
        $("#op-pub").click(function () {
            var btnTxt = "发布";
            opContentState(PUB, btnTxt);
        });
        $("#op-cpub").click(function () {
            var btnTxt = "下线";
            opContentState(CPUB, btnTxt);
        });
    });
})();

//搜索事件
 function func1() {            
    var srTxt = $("#banner-search").val();
    var href = "/admin.php/banner/lists/catid/" + ini_catid + "/state/" + ini_status;
    if (!srTxt) {
        window.location.href = href;
        return;
    }

    href += "/keyword/" + srTxt;
    window.location.href = href;
}

//回车提交事件
function texEnter(event){  
    if(event.keyCode==13) {
        func1();
    }
}
//--------回车提交事件完毕---------------------//
//获取选择的行
function getSelection(){
    var ids = [];
    $('#table').find("[name='id[]']").each(function () {
        if ($(this).prop("checked")) {
            ids.push($(this).val());
        }
    });

    return ids;
}

/**
 * 发布，下线广告
 * @param state 发布，下线
 * @param btnTxt 操作的名称
 * @param type  操作的类型【发布|推广】
 */
function opContentState(state, btnTxt) {
    selectIds = getSelection();
    if (!selectIds || selectIds.length < 1) {
        bootbox.alert("请选择要" + btnTxt + "的广告！");
        return;
    }
    $("#selectSubmit").text(btnTxt);
    var url = '/admin.php/banner/pubBanners';

    $.ajax(
        {
            url: url,
            data: {ids: selectIds, state: state},
            type: "post",
            dataType: 'json',
            success: function (data) {
                if (data.state == 1) {
                    bootbox.alert("操作成功。", function () {
                        window.location.reload();
                    });
                } else {
                    bootbox.alert("操作失败，请稍后重试！");
                }
            }
        });
}
function dopub(id, state) {
    $.ajax({
        url: '/admin.php/Banner/isState',
        data: {id: id, state: (-1 - state)},
        type: "get",
        success: function(data){
            if(data == 1){
                window.location.reload();
            }
        }
    });
}
